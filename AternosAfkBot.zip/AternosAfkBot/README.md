# AternosAfkBot
🚀 Aternos Afk Bot All Version Supported With Login System 

### Star The Repo if You Play Minecraft

### Star Rewards
- [ ] 10 Stars = KeepAlive.js (best for replit users)
- [ ] 25 Stars = Chat Support (More Chat Features)
- [ ] 40 Stars = SeeInventory (express Url To See invertory)
- [ ] 50 Stars = DiscordBotSupport (Send Messages/Commands from Discord to Bot)

### Features
- [ ] Help Collecting Item For Diamond
- [ ] Sleep
- [ ] Auto Eat 
- [x] Armor Manager (Manage Armor)
- [x] PvP (fight me BotName)
- [x] Guard (guard BotName)
- [x] Help (Help BotName)
- [x] Hi Ping (Hi BotName)


### Required Plugins (First Dont Add them if error then add)
1. GeyserMc 
2. ViaVersion 
3. ViaBackWards 

### How To Setup / Run
1. git clone https://github.com/healer-op/AternosAfkBot.git 
2. cd AternosAfkBot 
3. npm i 
4. npm start

### Bot Joined But Not Moving / Not Getting Damage 
1. Change Your Register Command to Login Command `config.json`
```
"register-cmd":"/login MR_MR121",
"login-cmd":"/login MR_MR121"
````
2. Try Restarting Bot Server


